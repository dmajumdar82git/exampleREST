package com.pro.rest;
import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import com.pro.model.User;
@Path("/consume")
public class ConsumeService {
	@Path("/xml")
	@POST
	@Consumes(MediaType.APPLICATION_XML)
	public String sendXml(List<User> userList){
		for(User user:userList){
			System.out.println(user);
		}
		return "Received: "+userList.size()+" entities";
	}
	@Path("/json")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public String sendJson(List<User> userList){
		for(User user:userList){
			System.out.println(user);
		}
		return "Received: "+userList.size()+" entities";
	}
}
