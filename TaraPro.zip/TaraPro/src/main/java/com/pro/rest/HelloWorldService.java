package com.pro.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.DefaultValue;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.MatrixParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import com.pro.model.User;

@Path("/hello")
public class HelloWorldService {
	List<User> userList = new ArrayList<User>();

	public HelloWorldService() {
		User user1 = new User();
		user1.setId(1);
		user1.setAge(36);
		user1.setName("soma");

		User user2 = new User();
		user2.setId(2);
		user2.setAge(38);
		user2.setName("debasri");

		User user3 = new User();
		user3.setId(3);
		user3.setName("divya");
		user3.setAge(39);

		userList.add(user1);
		userList.add(user2);
		userList.add(user3);
	}

	@GET
	@Path("/{param}")
	public Response getMsg(@PathParam("param") String msg) {
		String output = "Jersey say : " + msg;
		return Response.status(200).entity(output).build();
	}

	@Path("/users")
	@GET
	@Produces(MediaType.APPLICATION_XML)
	public List<User> fetchUsers() {
		return userList;
	}

	@GET
	@Path("/user")
	@Produces(MediaType.TEXT_PLAIN)
	public Response getUserDetail(
			@DefaultValue("ajnabee") @QueryParam("name") String name) {

		String output = "No user with name' " + name + "' present";

		if (name.equals("ajnabee"))
			output = "Hello, " + name;
		else {
			for (User user : userList) {
				if (user.getName().equals(name)) {
					output = name + " is of age " + user.getAge();
					break;
				}
			}
		}
		return Response.status(200).entity(output).build();
	}
	
	@GET
	@Path("/example")
	@Produces("text/plain")
	public String show(@Context UriInfo uriInfo){
		String name=uriInfo.getQueryParameters().getFirst("name");
        String msg=uriInfo.getQueryParameters().getFirst("msg");
		
		return name+" says "+msg;
	}
	
	@POST
	@Path("/form")
	@Produces(MediaType.TEXT_HTML)
	public Response showFormParam(@FormParam("name") String name,@FormParam("message") String message){
		//Service call to save Data in DB
		String output="<h2>"+name+" has send a message \""+message+"\".</h2>";		
		return Response.status(200).entity(output).build();
	}
	
	@Path("/matrix")
    @GET
    @Produces("text/html")
    public Response getUserByNameAndAge(@MatrixParam("name") String name,@MatrixParam("age") int age){
           
        //Service call to Get user Data based on name and state from DB
		
        String output ="";
        
        if(age>=18)
        	output="Name: "+name+", Status : Eligible to vote";
        else if(age<18)
        	output="Name: "+name+", Status : Not eligible to vote";
       
        return Response.status(200).entity(output).build();
    }
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/json")
	public List<User> getJsonResponse(){
		User user=new User();
		user.setId(4);
		user.setName("diptish");
		user.setAge(40);
		userList.add(user);
		return userList;
	}	
	
}
