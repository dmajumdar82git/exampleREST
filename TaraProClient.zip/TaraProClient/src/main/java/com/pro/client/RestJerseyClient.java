package com.pro.client;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

public class RestJerseyClient {

	static void queryParamEx(){
		Client client = ClientBuilder.newClient();
		//new ClientConfig().register(LoggingFilter.class)
		WebTarget webTarget = client.target(
				"http://localhost:8088/TaraPro/rest").path("hello/example")
				.queryParam("name", "debasri").queryParam("msg", "hi jersey client");

		Invocation.Builder invocationBuilder = webTarget
				.request(MediaType.TEXT_PLAIN);
		Response response = invocationBuilder.get();

		System.out.println(response.getStatus());
		String msg=response.readEntity(String.class);
		System.out.println(msg);
	}
	
	static void pathParamEx(){
		Client client = ClientBuilder.newClient();
		//new ClientConfig().register(LoggingFilter.class)
		WebTarget webTarget = client.target(
				"http://localhost:8088/TaraPro/rest").path("hello/jai tara maa");				

		Invocation.Builder invocationBuilder = webTarget
				.request(MediaType.TEXT_PLAIN);
		Response response = invocationBuilder.get();

		System.out.println(response.getStatus());
		String msg=response.readEntity(String.class);
		System.out.println(msg);
	}
	public static void main(String[] args) {
		//queryParamEx();
		//pathParamEx();
		/*Response in XML format */
		//listUsersEx();
		addUsersToListEx();
	}

	private static void listUsersEx() {
		Client client=ClientBuilder.newClient();
		WebTarget target=client.target("http://localhost:8088/TaraPro/rest/").path("hello/json");
		Invocation.Builder invocationBuilder = target
				.request(MediaType.APPLICATION_JSON);
		Response response=invocationBuilder.get();
		System.out.println(response.getStatus());
		
		String obj=response.readEntity(String.class);
		try {
			PrintWriter pw=new PrintWriter(new File("output.json"));
			pw.println(obj);
			pw.close();
			
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		}
		System.out.println("done");	
		
	}
	
	private static void addUsersToListEx(){
		Client client=ClientBuilder.newClient();
		WebTarget target=client.target("http://localhost:8088/TaraPro/rest/").path("consume/xml");
		Invocation.Builder invocationBuilder=target.request();		
		Response response=invocationBuilder.post(Entity.entity(new File("output.xml"),MediaType.APPLICATION_XML));
		System.out.println(response.getStatus());
		System.out.println(response.readEntity(String.class));
	}
}
