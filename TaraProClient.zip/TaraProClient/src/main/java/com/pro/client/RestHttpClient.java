package com.pro.client;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.InputStreamReader;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

public class RestHttpClient {
	static void queryParamEx() {
		try {
			CloseableHttpClient httpClient = HttpClients.createDefault();
			URIBuilder builder = new URIBuilder(
					"http://localhost:8080/TaraPro/rest/hello/example");

			builder.setParameter("name", "debasri");
			builder.setParameter("msg", "hi java REST");

			System.out.println("URL: " + builder.build());

			HttpGet getRequest = new HttpGet(builder.build());

			HttpResponse response = httpClient.execute(getRequest);
			if (response.getStatusLine().getStatusCode() != 200) {
				throw new RuntimeException(
						"Request Processing Failed : HTTP error code : "
								+ response.getStatusLine().getStatusCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader(
					(response.getEntity().getContent())));

			String output;
			System.out.println("Output received from Rest service ....");
			while ((output = br.readLine()) != null) {
				System.out.println(output);
			}
			httpClient.close();
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
	}
		static void addUsersToListEx(){
			try {
				CloseableHttpClient httpClient = HttpClients.createDefault();
				
			    //Define a postRequest request
		        HttpPost postRequest = new HttpPost("http://localhost:8080/TaraPro/rest/consume/json");
		         
		        //Set the API media type in http content-type header
		        postRequest.addHeader("content-type", "application/json");
		        
		        BufferedReader br =new BufferedReader(new FileReader(new File("output.json")));
		        
		        //Set the request post body
		        postRequest.setEntity(new StringEntity(br.readLine()));
		      //Send the request; It will immediately return the response in HttpResponse object if any
		        HttpResponse response = httpClient.execute(postRequest);
		         
		        //verify the valid error code first
		        int statusCode = response.getStatusLine().getStatusCode();
		        br.close();
		        if (statusCode != 200)
		        {
		            throw new RuntimeException("Failed with HTTP error code : " + statusCode);
		        }
		       
		        httpClient.close();
		        
		        
			}catch(Exception ex){
				System.out.println(ex.getMessage());
			}
		}
	static void listUsersEx(){
		try {
			CloseableHttpClient httpClient = HttpClients.createDefault();
			
			HttpGet getRequest = new HttpGet("http://localhost:8088/TaraPro/rest/hello/users");
			getRequest.addHeader("accept","application/XML");
			HttpResponse response = httpClient.execute(getRequest);
			if (response.getStatusLine().getStatusCode() != 200) {
				throw new RuntimeException(
						"Request Processing Failed : HTTP error code : "
								+ response.getStatusLine().getStatusCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader(
					(response.getEntity().getContent())));

			String output;
			System.out.println("Output received from Rest service ....");
			while ((output = br.readLine()) != null) {
				System.out.println(output);
			}
			httpClient.close();
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}

	}
	public static void main(String[] args) {
		//queryParamEx();
		//listUsersEx();
		addUsersToListEx();
	}

}
